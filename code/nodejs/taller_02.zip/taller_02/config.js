const config = {
    PORT: 3000,
    DB_URL: 'mongodb://dba:dba@mongodb-server:27017/miapp?authSource=admin'
}

module.exports = config